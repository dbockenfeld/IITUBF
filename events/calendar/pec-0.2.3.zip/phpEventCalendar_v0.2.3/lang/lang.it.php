<?
$lang['months'] = array("Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Lugio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre");
$lang['days'] = array("Domenica", "Lunedi'", "Martedi'", "Mercoledi'", "Giovedi'", "Venerdi'", "Sabato");
$lang['abrvdays'] = array("Dom", "Lun", "Mar", "Mer", "Gio", "Ven", "Sab");
// eventdisplay.php
$lang['otheritems'] = "Altro in questo giorno:";
$lang['deleteconfirm'] = "Sei sicuro di voler cancellare questi elementi?";
$lang['postedby'] = "Scritto da";
// index.php
$lang['login'] = "Autentica";
$lang['logout'] = "Esci";
$lang['adminlnk'] = "Amministrazione";
$lang['changepw'] = "Cambia Password";
?>