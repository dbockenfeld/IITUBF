<?php
//Versi�n en espa�ol
//traduci�n realizada por ALSo NET (also@lemetofuego.com)

$lang['months'] = array("Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre");
$lang['days'] = array("Domingo", "Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "S�bado");
$lang['abrvdays'] = array("DOM", "LUN", "MAR", "MIE", "JUV", "VIE", "SAB");

// eventdisplay.php
$lang['otheritems'] = "Tambien en este d�a:";
$lang['deleteconfirm'] = "Est�s seguro de querer borrar este acto?";
$lang['postedby'] = "Insertado por";

// index.php
$lang['login'] = "Login";
$lang['logout'] = "Logout";
$lang['adminlnk'] = "User Admin";
$lang['changepw'] = "Cambiar Password";
?>
