<?php
$lang['months'] = array("Januar", "Februar", "M&auml;rz", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember");
$lang['days'] = array("Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag");
$lang['abrvdays'] = array("So", "Mo", "Di", "Mi", "Do", "Fr", "Sa");

// eventdisplay.php
$lang['otheritems'] = "Weiteres an diesem Tag:";
$lang['deleteconfirm'] = "Sind Sie sicher, dass Sie diesen Eintrag l&ouml;schen m&ouml;chten?";
$lang['postedby'] = "Eingetragen von";

// index.php
$lang['login'] = "Login";
$lang['logout'] = "Logout";
$lang['adminlnk'] = "Benutzer Administrator";
$lang['changepw'] = "Passwort &auml;ndern";
?>
