<?php
$lang['months'] = array("Januari", "Februari", "Maart", "April", "Mei", "Juni", "Juli", "Augustus", "September", "Oktober", "November", "December");
$lang['days'] = array("Zondag", "Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag", "Zaterdag");
$lang['abrvdays'] = array("Zon", "Ma", "Di", "Wo", "Do", "Vr", "Za");

// eventdisplay.php
$lang['otheritems'] = "Tevens deze dag:";
$lang['deleteconfirm'] = "Weet u het zeker dat u dit item wilt verwijderen?";
$lang['postedby'] = "Gepost door:";

// index.php
$lang['login'] = "Inloggen";
$lang['logout'] = "Uitloggen";
$lang['adminlnk'] = "Beheerder";
$lang['changepw'] = "Wijzig Wachtwoord";
?>
