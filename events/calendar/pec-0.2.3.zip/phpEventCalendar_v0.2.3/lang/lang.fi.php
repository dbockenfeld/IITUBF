<?php
$lang['months'] = array("Tammikuu", "Helmikuu", "Maaliskuu", "Huhtikuu", "Toukokuu", "Kes�kuu", "Hein�kuu", "Elokuu", "Syyskuu", "Lokakuu", "Marraskuu", "Joulukuu");
$lang['days'] = array("Sunnuntau", "Maanantai", "Tiistai", "Keskiviikko", "Torstai", "Perjantai", "Lauantai");
$lang['abrvdays'] = array("Su", "Ma", "Ti", "Ke", "To", "Pe", "La");

// eventdisplay.php
$lang['otheritems'] = "My�s t�n��n:";
$lang['deleteconfirm'] = "Oletko varma ett� haluat poistaa t�m�n merkinn�n?";
$lang['postedby'] = "Lis�nnyt";

// index.php
$lang['login'] = "Kirjaudu";
$lang['logout'] = "Kirjaudu ulos";
$lang['adminlnk'] = "K�ytt�j�t";
$lang['changepw'] = "Vaihda salasana";
?>
