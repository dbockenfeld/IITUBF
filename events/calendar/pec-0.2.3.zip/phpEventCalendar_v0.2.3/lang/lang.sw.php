<?
$lang['months'] = array("Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December");
$lang['days'] = array("S�ndag", "M�ndag", "Tisdag", "Onsdag", "Torsdag", "Fredag", "L�rdag");
$lang['abrvdays'] = array("S�n", "M�n", "Tis", "Ons", "Tors", "Fre", "L�r");

// eventdisplay.php
$lang['otheritems'] = "Detta h�nder ocks� idag:";
$lang['deleteconfirm'] = "�r du s�ker p� att du vill ta bort h�ndelsen?";
$lang['postedby'] = "Inf�rt av";

// index.php
$lang['login'] = "Logga in";
$lang['logout'] = "Logga ut";
$lang['adminlnk'] = "Administrat�r";
$lang['changepw'] = "�ndra L�senord";

// eventform.php
$lang['cancel'] = "Annullera";
?>