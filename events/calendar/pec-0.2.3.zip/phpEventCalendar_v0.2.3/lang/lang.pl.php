<?
$lang['months'] = array("Styczen", "Luty", "Marzec", "Kwiecien", "Maj", "Czerwiec", "Lipiec", "Sierpien", "Wrzesien", "Pazdziernik", "Listopad", "Grudzien");
$lang['days'] = array("Niedziela", "Poniedzia�ek", "Wtorek", "Sroda", "Czwartek", "Piatek", "Sobota");
$lang['abrvdays'] = array("Ndz", "Pon", "Wt", "Sr", "Czw", "Pt", "Sob");

// eventdisplay.php
$lang['otheritems'] = "W tym samym dniu:";
$lang['deleteconfirm'] = "Czy jestes pewien ze czcesz to skasowac?";
$lang['postedby'] = "Napisane przez";

// index.php
$lang['login'] = "Logowanie";
$lang['logout'] = "Wylogowanie";
$lang['adminlnk'] = "Administracja";
$lang['changepw'] = "Zmien haslo";
?>
