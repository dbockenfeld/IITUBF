<?php
/*
Phpeventcalendar translated for Portuguese by SlackerSoul 2003
Slackersoul@mail.pt
*/

$lang['months'] = array("Janeiro", "Fevereiro", "Mar�o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro");
$lang['days'] = array("Domingo", "Segunda", "Ter�a", "Quarta", "Quinta", "Sexta", "S�bado");
$lang['abrvdays'] = array("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab");

// eventdisplay.php
$lang['otheritems'] = "Tamb�m neste dia:";
$lang['deleteconfirm'] = "Tem a certeza que quere apagar este item?";
$lang['postedby'] = "Enviado por";

// index.php
$lang['login'] = "Login";
$lang['logout'] = "Logout";
$lang['adminlnk'] = "Administra��o";
$lang['changepw'] = "Alterar Password";
?>
