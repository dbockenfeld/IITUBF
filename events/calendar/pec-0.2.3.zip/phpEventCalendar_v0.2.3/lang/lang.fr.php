<?php
$lang['months'] = array("Janvier", "F�vrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Ao�t", "Septembre", "Octobre", "Novembre", "Decembre");
$lang['days'] = array("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi");
$lang['abrvdays'] = array("Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam");

// eventdisplay.php
$lang['otheritems'] = "Le m�me Jour:";
$lang['deleteconfirm'] = "Etes vous s�r de vouloir effacer ceci?";
$lang['postedby'] = "Ecrit par";

// index.php
$lang['login'] = "Se Logger";
$lang['logout'] = "Se D�logger";
$lang['adminlnk'] = "Administration";
$lang['changepw'] = "Changer le Mot de Passe";
?>
