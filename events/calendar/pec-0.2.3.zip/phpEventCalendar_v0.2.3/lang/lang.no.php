<?
$lang['months'] = array("Januar", "Februar", "Mars", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Desember");
$lang['days'] = array("S�ndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "L�rdag");
$lang['abrvdays'] = array("S�n", "Man", "Tirs", "Ons", "Tors", "Fre", "L�r");

// eventdisplay.php
$lang['otheritems'] = "Ogs� p� denne dagen:";
$lang['deleteconfirm'] = "Er du sikker p� du vil slette denne avtalen?";
$lang['postedby'] = "Innlagt av";

// index.php
$lang['login'] = "Login";
$lang['logout'] = "Avslutt";
$lang['adminlnk'] = "Bruker Admin";
$lang['changepw'] = "Skift Passord";
?>