<?php
$lang['months'] = array("Januar", "Februar", "Marts", "April", "Maj", "Juni", "Juli", "August", "September", "Oktober", "November", "December");
$lang['days'] = array("S�ndag", "Mandag", "Tirsdag", "Onsdag", "Torsdag", "Fredag", "L�rdag");
$lang['abrvdays'] = array("S�n", "Man", "Tirs", "Ons", "Tors", "Fre", "L�r");

// eventdisplay.php
$lang['otheritems'] = "Det sker ogs� idag:";
$lang['deleteconfirm'] = "Er du sikker p� du vil slette denne aftale?";
$lang['postedby'] = "Tilf�jet af";

// index.php
$lang['login'] = "Login";
$lang['logout'] = "Logud";
$lang['adminlnk'] = "Bruger Admin";
$lang['changepw'] = "Skift Kodeord";
?>
